/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ru', {
	clear: 'Очистить',
	highlight: 'Под курсором',
	options: 'Настройки цвета',
	selected: 'Выбранный цвет',
	title: 'Выберите цвет'
} );
